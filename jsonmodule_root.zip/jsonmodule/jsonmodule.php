<?php

if (!defined('_PS_VERSION_'))
	exit;

class jsonModule extends Module
{

	protected $_errors = array();
	protected $_html = '';

	/* Set default configuration values here */
	protected $_config = array(
		'jsonld_legal_name' => ''
		);


	public function __construct()
	{
		$this->name = 'jsonmodule';
		$this->tab = 'front_office_features';
		$this->version = '1.0';
		$this->author = 'Nemo';
		$this->need_instance = 0;
		
		$this->bootstrap = true;

	 	parent::__construct();

		$this->displayName = $this->l('Google JSON ID');
		$this->description = $this->l('Adds Google rich snippets in json ID format');
		$this->confirmUninstall = $this->l('Are you sure you want to delete this module?');
	}
	
	public function install()
	{
		if (!parent::install() OR
			!$this->_installConfig() OR
			!$this->registerHook('displayHeader')
			)
			return false;
		return true;
	}
	
	public function uninstall()
	{
		if (!parent::uninstall() OR
			!$this->_eraseConfig()
			)
			return false;
		return true;
	}

	private function _installConfig()
	{
		foreach ($this->_config as $keyname => $value) {
			Configuration::updateValue($keyname, $value);
		}
		return true;
	}


	private function _eraseConfig()
	{
		foreach ($this->_config as $keyname => $value) {
			Configuration::deleteByName($keyname);
		}
		return true;
	}

	public function getContent()
	{
		$this->_postProcess();
		$this->_displayForm();

		return	$this->_html;
	}
	
	private function _displayForm()
	{
		$this->_html .= $this->_generateForm();
		// With Template
		// $this->context->smarty->assign(array(
		// 	'variable'=> 1
		// ));
		// $this->_html .= $this->display(__FILE__, 'backoffice.tpl');
	}

	private function _generateForm()
	{
		$inputs = array();

		$inputs[] = array(
			'type' => 'text',
			'label' => $this->l('Legal Name'),
			'name' => 'jsonld_legal_name',
			'desc' => 'Legal name of your business'
			);


		$fields_form = array(
			'form' => array(
				'legend' => array(
					'title' => $this->l('Settings'),
					'icon' => 'icon-cogs'
					),
				'input' => $inputs,
				'submit' => array(
					'title' => $this->l('Save'),
					'class' => 'btn btn-default pull-right',
					'name' => 'submitUpdate'
					)
				)
			);



		$lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
		$helper = new HelperForm();
		$helper->default_form_language = $lang->id;
		// $helper->submit_action = 'submitUpdate';
		$helper->currentIndex = $this->context->link->getAdminLink('AdminModules',false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->tpl_vars = array(
			'fields_value' => $this->getConfig(),
			'languages' => $this->context->controller->getLanguages(),
			'id_language' => $this->context->language->id
		);
		return $helper->generateForm(array($fields_form));
	}


	private function _postProcess()
	{
		if (Tools::isSubmit('submitUpdate')) // handles the basic config update
		{
			// Do anything, like updating config
			foreach ($this->_config as $key => $unused) {
				Configuration::updateValue($key, Tools::getValue($key));
			}
			// Error handling
			if ($this->_errors) {
				$this->_html .= $this->displayError(implode($this->_errors, '<br />'));
			} else $this->_html .= $this->displayConfirmation($this->l('Settings Updated!'));
		}
	}

	public function getConfig()
	{
		$config_keys = array_keys($this->_config);
		return Configuration::getMultiple($config_keys);
	}

    public function getPath($id_category, $path = [], $link_on_the_item = false, $category_type = 'products', Context $context = null)
    {
        if (!$context) {
            $context = Context::getContext();
        }

        $id_category = (int)$id_category;
        if ($id_category == 1) {
            return '<span class="navigation_end">'.$path.'</span>';
        }

        $pipe = Configuration::get('PS_NAVIGATION_PIPE');
        if (empty($pipe)) {
            $pipe = '>';
        }

        $full_path = [];
        if ($category_type === 'products') {
            $interval = Category::getInterval($id_category);
            $id_root_category = $context->shop->getCategory();
            $interval_root = Category::getInterval($id_root_category);
            if ($interval) {
                $sql = 'SELECT c.id_category, cl.name, cl.link_rewrite
						FROM '._DB_PREFIX_.'category c
						LEFT JOIN '._DB_PREFIX_.'category_lang cl ON (cl.id_category = c.id_category'.Shop::addSqlRestrictionOnLang('cl').')
						'.Shop::addSqlAssociation('category', 'c').'
						WHERE c.nleft <= '.$interval['nleft'].'
							AND c.nright >= '.$interval['nright'].'
							AND c.nleft >= '.$interval_root['nleft'].'
							AND c.nright <= '.$interval_root['nright'].'
							AND cl.id_lang = '.(int)$context->language->id.'
							AND c.active = 1
							AND c.level_depth > '.(int)$interval_root['level_depth'].'
						ORDER BY c.level_depth ASC';
                $categories = Db::getInstance()->executeS($sql);

                $n = 1;
                $n_categories = count($categories);
                foreach ($categories as $category) {
                	$full_path[] = ['name' => $category['name'], 'url' => $context->link->getCategoryLink((int)$category['id_category'], $category['link_rewrite'])];
                    // $full_path .=
                    // (($n < $n_categories || $link_on_the_item) ? '<a href="'.Tools::safeOutput($context->link->getCategoryLink((int)$category['id_category'], $category['link_rewrite'])).'" title="'.htmlentities($category['name'], ENT_NOQUOTES, 'UTF-8').'" data-gg="">' : '').
                    // htmlentities($category['name'], ENT_NOQUOTES, 'UTF-8').
                    // (($n < $n_categories || $link_on_the_item) ? '</a>' : '').
                    // (($n++ != $n_categories || !empty($path)) ? '<span class="navigation-pipe">'.$pipe.'</span>' : '');
                }

                return array_merge($full_path, $path);
            }
        } elseif ($category_type === 'CMS') {
            $category = new CMSCategory($id_category, $context->language->id);
            if (!Validate::isLoadedObject($category)) {
                die(Tools::displayError());
            }
            $category_link = $context->link->getCMSCategoryLink($category);

            if ($path != $category->name) {
            	$full_path[] = ['name' => $category->name, 'url' => $category_link];
                // $full_path .= '<a href="'.Tools::safeOutput($category_link).'" data-gg="">'.htmlentities($category->name, ENT_NOQUOTES, 'UTF-8').'</a><span class="navigation-pipe">'.$pipe.'</span>'.$path;
            } else {
            	$full_path[] = ['name' => $path, 'url' => $category_link];
                // $full_path = ($link_on_the_item ? '<a href="'.Tools::safeOutput($category_link).'" data-gg="">' : '').htmlentities($path, ENT_NOQUOTES, 'UTF-8').($link_on_the_item ? '</a>' : '');
            }

            return $this->getPath($category->id_parent, $full_path, $link_on_the_item, $category_type);
        }
    }

	public function hookDisplayHeader($params)
	{

		$path = [];
		if(isset($this->context->controller->php_self) && 'product' == $this->context->controller->php_self) {

			$product = new Product((int)Tools::getValue('id_product'), true, $this->context->language->id);
			if (!Validate::isLoadedObject($product))
				return false;
// d($product);
			$cover = Product::getCover($product->id);
			$image = $this->context->link->getImageLink($product->link_rewrite, $cover['id_image']);
			$this->context->smarty->assign(array(
				'product'=> $product,
				'image' => $image ?: ''
			));
			// reviews
			include_once(dirname(__FILE__).'/../reviewsnippets/classes/reviewshelp.class.php');
			$obj_reviewshelp = new reviewshelp();
			$this->context->smarty->assign(
				array(
						'nbReviews' => (int)($obj_reviewshelp->getCountReviews(
																	  array(
																	  		'id_product' => (int)(Tools::getValue('id_product'))
																	  		)
																	  )
											  ),
						'avg_decimal' => ($obj_reviewshelp->getAvgDecimal(
																	  array(
																	  		'id_product' => (int)(Tools::getValue('id_product'))
																	  		)
																	  )
						)
					 )
				);

			$this->context->smarty->assign(array(
				'isproduct'=> 1
			));
			$path = $this->getPath($product->id_category_default);
		} // end if product

		if ($id_category = Tools::getValue('id_category')) {
			$path = $this->getPath((int)$id_category);
		}

		if(!$path && isset($this->context->controller->php_self)) // another page
		{
			$metas = Meta::getMetaTags($this->context->language->id, $this->context->controller->php_self);
			if($metas)
				$path[] = ['name' => str_replace(' - RC Planet', '', $metas['meta_title']), 'url' => $this->context->link->getPageLink($this->context->controller->php_self)];
		}
		if(is_array($path) && $path)
		{
			$this->context->smarty->assign(array(
				'path'=> $path
			));
		}

		foreach ($this->_config as $key => $unused)
			$to_assign[$key] = Configuration::get($key);

		$this->context->smarty->assign($to_assign);

		$site_url = $this->context->link->getPageLink('index');

		$needed_fields = [
		'PS_SHOP_NAME',
		'PS_SHOP_EMAIL',
		'PS_SHOP_ADDR1',
		'PS_SHOP_ADDR2',
		'PS_SHOP_CODE',
		'PS_SHOP_CITY',
		'PS_SHOP_COUNTRY_ID',
		'PS_SHOP_STATE_ID',
		'PS_SHOP_PHONE'
		];
		$config = Configuration::getMultiple($needed_fields);

		$this->context->smarty->assign($config);

		if($config['PS_SHOP_COUNTRY_ID'])
		{
			$country = new Country($config['PS_SHOP_COUNTRY_ID']);
			$this->context->smarty->assign(array(
				'country_iso' => $country->iso_code
			));
		}
		if($config['PS_SHOP_STATE_ID'])
		{
			$state = new State($config['PS_SHOP_STATE_ID']);
			$this->context->smarty->assign(array(
				'state_iso' => $state->iso_code
			));
		}

		$this->context->smarty->assign(array(
			'logo'=> $this->context->link->getMediaLink(_PS_IMG_.Configuration::get('PS_LOGO_MOBILE').'?'.Configuration::get('PS_IMG_UPDATE_TIME')),
			'site_url' => $this->context->link->getPageLink('index')
		));

		return $this->display(__FILE__, 'jsonmodule.tpl');

		

	}

}
